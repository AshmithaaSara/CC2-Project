import Popup from 'reactjs-popup';
import React, { useEffect, useState } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import TextField from '@material-ui/core/TextField';
import { Container, Paper, Button } from '@material-ui/core';
import axios from 'axios';
const useStyles = makeStyles((theme) => ({
  root: {
    '& > *': {
      margin: theme.spacing(1),
    },
  },
}));

export default function Patient() {
  const paperStyle = { padding: '50px 20px', width: 700, margin: '20px auto' };
  const [id,setId]=useState('');
  const [name, setName] = useState('');
  const [hemoglobin, sethemoglobin] = useState('');
  const [blood_pressure,setBlood_pressure]=useState('');
  const [sugar_level,setSugar_level]=useState('');
  const [height,setHeight]=useState('');
  const [weight,setWeight]=useState('');
  const [details, setDetails] = useState([]);
  const [trigger,setTrigger]=useState(0);


// const handleGet = () => {
// 	fetch('http://localhost:8081/get')
// 	.then((res) => res.json())
// 	.then((result) => {
// 	console.log(result);
// 	})
// 	.catch((error) => {
// 	console.error(error);
// 	});
// 	};



  const handlePost = (e) => {
    e.preventDefault();
    const student = {id,name};
    console.log(student);
    fetch('http://localhost:8081/post', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(student),
    })
      .then(() => {
        console.log('New user added');
        setTrigger(trigger+1);
        
      });
  };



  const handlePut = (usid) => {
    const data = {
      id:usid,
      name:name,
      hemoglobin:hemoglobin,
      blood_pressure:blood_pressure,
      sugar_level:sugar_level,
      height:height,
      weight:weight
    };
    axios
      .put("http://localhost:8081/put", data)
      .then((response) => {
        console.log(response.data);
        setTrigger(trigger+1)
      })
      .catch((error) => {
        console.error(error);
      });
  };
  


  const handleDelete = (id) => {
    axios.delete(`http://localhost:8081/delete?id=${id}`)
    .then(response=>{
        console.log("user detail deleted");
        setTrigger(trigger+1)
    })
  };
  const url="https://img.freepik.com/premium-vector/brunette-man-avatar-portrait-young-guy-vector-illustration-face_217290-1035.jpg?w=826";

  useEffect(() => {
    fetch('http://localhost:8081/get')
      .then((res) => res.json())
      .then((result) => {
        setDetails(result);
        console.log(details)
      });
  }, [trigger]);

  return (
    <div >
        <h1>HEALTH MONITOR </h1>
        <div style={{
   backgroundRepeat:"no-repeat",backgroundSize:"cover"}}>
        {details.map((student) => (
        // <Paper elevation={3} style={paperStyle} key={student.id}>

          <div className="output">
            <div style={{ display:"flex" }}>
                 <div style={{width:400,height:200,border:"2px solid black"}}>
                 <img src={url} style={{width:100,paddingTop:10}}/>
                 <br/>
                 <h1 style={{fontSize:20}}>USER ID : {student.id}</h1>
                 <h1 style={{fontSize:20}}>NAME : {student.name}</h1>
                 </div >

                 <div style={{width:600,height:200,border:"2px solid black"}}>
                    <h1 style={{fontSize:20,color:"red"}}>Health Details</h1>
                    <h3>Hemoglobin : {student.hemoglobin}</h3>
                    <h3>Blood Pressure : {student.blood_pressure}</h3>
                    <h3>Sugar Level : {student.sugar_level}</h3>
                 </div>
                 <div style={{width:300,height:200,border:"2px solid black"}}>
                    <br/>
                    <Button variant="contained" color="secondary" onClick={() => handleDelete(student.id)} > Delete</Button>
                        
                        <br/>
                        <br/>
                        <br/>
                        <br/>
                        <br/>
                        

              <Popup
trigger={ <Button variant="contained" color="secondary" > update</Button>}
modal
nested
>
{(close) => (
  
<div >
 <Container>
      <Paper elevation={3} style={paperStyle}>
     
       
        <h1 style={{ color: 'blue' }}>USER HEALTH DETAILS</h1>
        <form noValidate autoComplete="off">
          <TextField id="outlined-basic" style={{marginBottom:14}} label="user Name" variant="outlined" fullWidth value={name} onChange={(e) => setName(e.target.value)}/>
          <TextField id="outlined-basic" style={{marginBottom:14}} label="user hemoglobin" variant="outlined" fullWidth value={hemoglobin} onChange={(e) => sethemoglobin(e.target.value)}/>
          <TextField id="outlined-basic" style={{marginBottom:14}} label="user blood_pressure" variant="outlined" fullWidth value={blood_pressure} onChange={(e) => setBlood_pressure(e.target.value)}/>
          <TextField id="outlined-basic" style={{marginBottom:14}} label="user sugar_level" variant="outlined" fullWidth value={sugar_level} onChange={(e) => setSugar_level(e.target.value)}/>
          <TextField id="outlined-basic" style={{marginBottom:14}} label="user height" variant="outlined" fullWidth value={height} onChange={(e) => setHeight(e.target.value)}/>
          <TextField id="outlined-basic" style={{marginBottom:14}} label="user weight" variant="outlined" fullWidth value={weight} onChange={(e) => setWeight(e.target.value)}/>

          <Button variant="contained" color="secondary" onClick={() => handlePut(student.id)}>
            Submit
          </Button>
          <br/><br/>
<button onClick={close}>Close modal</button>
        </form>
       
       </Paper>
      </Container>
     

</div>
)}
</Popup> 
              </div>            
            </div>
          </div>
   
      ))}
        </div>
        <br/>
        <br/>
   <Popup
trigger={ <Button variant="contained" color="secondary" > ADD THE USER DETAILS</Button>}
modal
nested
>
{(close) => (
  
<div >
 <Container>
      <Paper elevation={3} style={paperStyle}>
     
       
        <h1 style={{ color: 'blue' }}>USER HEALTH DETAILS</h1>
        <form noValidate autoComplete="off">
          <TextField id="outlined-basic" style={{marginBottom:14}} label="user id" variant="outlined" fullWidth value={id} onChange={(e) => setId(e.target.value)}/>
          <TextField id="outlined-basic" style={{marginBottom:14}} label="user Name" variant="outlined" fullWidth value={name} onChange={(e) => setName(e.target.value)}/>
          <TextField id="outlined-basic" style={{marginBottom:14}} label="user hemoglobin" variant="outlined" fullWidth value={hemoglobin} onChange={(e) => sethemoglobin(e.target.value)}/>
          <TextField id="outlined-basic" style={{marginBottom:14}} label="user blood_pressure" variant="outlined" fullWidth value={blood_pressure} onChange={(e) => setBlood_pressure(e.target.value)}/>
          <TextField id="outlined-basic" style={{marginBottom:14}} label="user sugar_level" variant="outlined" fullWidth value={sugar_level} onChange={(e) => setSugar_level(e.target.value)}/>
          <TextField id="outlined-basic" style={{marginBottom:14}} label="user height" variant="outlined" fullWidth value={height} onChange={(e) => setHeight(e.target.value)}/>
          <TextField id="outlined-basic" style={{marginBottom:14}} label="user weight" variant="outlined" fullWidth value={weight} onChange={(e) => setWeight(e.target.value)}/>

          <Button variant="contained" color="secondary" onClick={handlePost}>
            Submit
          </Button>
          <br/><br/>
<button onClick={close}>Close modal</button>
        </form>
       
       </Paper>
      </Container>
     

</div>
)}
</Popup> 
     
      </div>
)} 



