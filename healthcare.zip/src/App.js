import logo from './logo.svg';
import './App.css';
import Patient from './patient_details';

function App() {
  return (
    <div className="App">
     <Patient/>
    </div>
  );
}

export default App;
